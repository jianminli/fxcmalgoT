import requests
from socketIO_client import SocketIO
import csv

if __name__ == '__main__':
    TRADING_API_URL = 'https://api-demo.fxcm.com:443'
    WEBSOCKET_PORT = 443
    socketIO = None
    ACCESS_TOKEN = "8fbaf10ac4df43389248eaa2a543497b307fab1b"

    socketIO = SocketIO(TRADING_API_URL, WEBSOCKET_PORT, params={'access_token': ACCESS_TOKEN})
    bearer_access_token = "Bearer {0}{1}".format(socketIO._engineIO_session.id,ACCESS_TOKEN)
    headers = { 'User-Agent': 'request',
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization' : bearer_access_token}

    instrument_file = "eurusd.csv"
    instrument_id = "1"
    period_id = "m1"
    num = 4000

    f = csv.writer(open(instrument_file, "w+"))
    f.writerows(requests.get('https://api-demo.fxcm.com:443/candles/'+instrument_id+'/'+period_id,
                             headers=headers, params={'num':num}).json()['candles'])
